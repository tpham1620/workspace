/**
 * 
 */
package AuctionCentral;

import java.text.ParseException;
import java.time.YearMonth;
import java.util.Calendar;
import java.util.Scanner;

/**
 * @author Indiana
 * Sets up the Auction Central Employee view for the Auction Central Project.
 */
public class AuctionCentralEmployee {
	
	/**
	 * Holds the calendar for use by ACE.
	 */
	private static AuctionCentral.MyCalendar myCalendar;
	
	/**
	 * Holds the name for the employee.
	 */
	private String employeeName;

	/**
	 * Gets input from the user.
	 */
	private static Scanner myIn;
	
	/**
	 * Holds the date to check.
	 */
	YearMonth date;
	
	/**
	 * 
	 */
	public AuctionCentralEmployee(AuctionCentral.MyCalendar calendar, String name) {
		myCalendar = calendar;
		employeeName = name;
	}
	
	/**
	 * Returns the employee name.
	 * @return the bidderName
	 */
	public String getEmployeeName() {
		return employeeName;
	}
	
	/**
	 * Views the calendar of upcoming auctions.
	 * @throws ParseException if failed.
	 */
	static void viewCurrentCalendar() throws ParseException {
		System.out.println(myCalendar.getCurrentMonthCalendarView());
	}
	
	/**
	 * Views auction details.
	 * @throws ParseException if failed.
	 */
	static void viewCalendar(YearMonth date) throws ParseException {
		myCalendar.getAnyMonthCalendarView(date);
	}
}