package AuctionCentral;

import java.time.YearMonth;
import java.util.Scanner;

public class AuctionCentralEmployeeInterface {
	
	/**
	 * Holds the date to check.
	 */
	YearMonth date;
	
	/**
	 * Gets input from the user.
	 */
	private static Scanner myIn;
	
	/**
	 * The interface for the ACE.
	 */
	public void employeeInterface(String employeeName){
		int input;
		while(true){
			System.out.println("Welcome " + employeeName);
			System.out.println("Please enter a command:\n0:log out\n1: view current calendar date\n2: view selected calendar date.\n3: view selected auction\n");
			input = myIn.nextInt();
			if(input == 0){	//break the while loop, end bidderInterface(), return control back to main class.
				break;
			}else if(input == 1){
				AuctionCentralEmployee.viewCurrentCalendar();
			}else if(input == 2){
				System.out.println("Please enter the year you wish to look at: ");
				int value = myIn.nextInt();
				System.out.println("Please enter the month you wish to look at: ");
				int value2 = myIn.nextInt();
				date = new YearMonth(value, value2);
				AuctionCentralEmployee.viewCalendar(date);
			}else{
				System.out.println("Invalid input");
			}
		}

	}
}
