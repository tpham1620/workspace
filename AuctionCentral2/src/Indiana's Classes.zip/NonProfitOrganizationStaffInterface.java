package AuctionCentral;

import java.util.Scanner;

public class NonProfitOrganizationStaffInterface {

	/**
	 * Gets input from the user.
	 */
	private Scanner myIn;
	
	/**
	 * The interface for the ACE.
	 */
	public void organizationInterface(MyCalendar calendar, String org, String rep){
		int input;
		NonProfitOrganizationStaff customer = new NonProfitOrganizationStaff(calendar, org, rep);
		while(true){
			System.out.println("Welcome " + rep);
			System.out.println("Please enter a command:\n0:log out\n1: add new auction\n2: edit auction.\n3: add new item\n4: edit item\n");
			input = myIn.nextInt();
			if(input == 0){	//break the while loop, end bidderInterface(), return control back to main class.
				break;
			}else if(input == 1 && customer.myAddAuction){
				NonProfitOrganizationStaff.addNewAuction();
			}else if(input == 2 && customer.myEditAuction){
				NonProfitOrganizationStaff.editAuction();
			}else if(input == 3 && customer.myAddItem) {
				NonProfitOrganizationStaff.addNewItem();
			}else if(input == 4 && customer.myEditItem) {
				System.out.println("Please enter the item id number(id number is the items entry number): ");
				int id = myIn.nextInt();
				NonProfitOrganizationStaff.editItem();
			}else{
				System.out.println("Invalid input");
			}
		}

	}
}
