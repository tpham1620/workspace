/**
 * 
 */
package AuctionCentral;

import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 * @author Indiana
 * Sets up the Non-Profit view of the Auction Central Project.
 */
public class NonProfitOrganizationStaff {

	
	/**
	 * Holds the calendar.
	 */
	private AuctionCentral.MyCalendar myCalendar;
	
	/**
	 * Holds the NPO name.
	 */
	private static String myOrganizationName;

	/**
	 * Gets input from the user.
	 */
	private static Scanner myIn;

	/**
	 * Holds the representative name.
	 */
	private String myRepresentativeName;
		
	/**
	 * Holds the auction date.
	 */
	static Date myDate;
	
	/**
	 * Holds the item.
	 */
	static Items myItem;
	
	/**
	 * Holds the month.
	 */
	static String myMonth;
	
	/**
	 * Holds the day.
	 */
	static int myDay;
	
	/**
	 * Holds the year.
	 */
	static int myYear;
	
	/**
	 * Holds the start time.
	 */
	static String myStart;
	
	/**
	 * Holds the end time.
	 */
	static String myEnd;
	
	/**
	 * Holds the auction title.
	 */
	String title;
	
	/**
	 * Auction editing permission.
	 */
	static Boolean myEditAuction;
	
	/**
	 * Auction creation permission.
	 */
	Boolean myAddAuction;
	
	/**
	 * Add item permission.
	 */
	static Boolean myAddItem;
	
	/**
	 * Edit item permission.
	 */
	static Boolean myEditItem;
	
	/**
	 * A counter for the item id.
	 */
	static int myCounter;
	
	/**
	 * Holds the auction.
	 */
	static Auction myAuction;
	
	/**
	 * 
	 * @param calendar
	 * @param org
	 * @param rep
	 */
	public NonProfitOrganizationStaff(MyCalendar calendar, String org, String rep) {
		myCalendar = calendar;
		myOrganizationName = org;
		myRepresentativeName = rep;
		myEditAuction = false;
		myAddAuction = true;
		myAddItem = false;
		myEditItem = false;
		myCounter = 0;
	}
	
	/**
	 * Adds a new auction to the calendar for this non profit organization.
	 */
	@SuppressWarnings("deprecation")
	static
	void addNewAuction() {
		System.out.println("Enter the auction month as a number: ");
		int month = myIn.nextInt();
		while(month < 1 || month > 12) {
			System.out.println("Error. Could not set date. Enter the auction month: ");
			month = myIn.nextInt();
		}
		if(month == 1) {
			myMonth = "January";
		} else if(month == 2) {
			myMonth = "February";
		} else if(month == 3) {
			myMonth = "March";
		} else if(month == 4) {
			myMonth = "April";
		} else if(month == 5) {
			myMonth = "May";
		} else if(month == 6) {
			myMonth = "June";
		} else if(month == 7) {
			myMonth = "July";
		} else if(month == 8) {
			myMonth = "August";
		} else if(month == 9) {
			myMonth = "September";
		} else if(month == 10) {
			myMonth = "October";
		} else if(month == 11) {
			myMonth = "November";
		} else {
			myMonth = "December";
		}
		myDate.setMonth(month);
		System.out.println("Enter the auction day: ");
		int day = myIn.nextInt();
		while(day < 1 || day > 30) {
			System.out.println("Error. Could not set date. Enter the auction day: ");
			day = myIn.nextInt();
		}
		myDay = day;
		myDate.setDate(day);
		System.out.println("Enter the auction year: ");
		int year = myIn.nextInt();
		while(year < Calendar.YEAR && myYear == year) {
			System.out.println("Error. Could not set date. Enter the auction year: ");
			year = myIn.nextInt();
		}
		myYear = year;
		myDate.setYear(year);
		System.out.println("Enter the auction start hour(between 0 and 23): ");
		int start = myIn.nextInt();
		while(start < 0 || start >= 24) {
			System.out.println("Error. Could not set date. Enter the auction hour: ");
			start = myIn.nextInt();
		}
		if(start < 12) {
			myStart = (start + ":00am");
		} else {
			myStart = (start - 12 + ":00pm");
		}
		myDate.setHours(start);
		myDate.setMinutes(0);
		myDate.setSeconds(0);
		System.out.println("Enter the auction end hour(between 0 and 23): ");
		int end = myIn.nextInt();
		while(end < 0 || end > 23) {
			System.out.println("Error. Could not set date. Enter the auction hour: ");
			end = myIn.nextInt();
		}
		if(end < 12) {
			myEnd = (end + ":00am");
		} else {
			myEnd = (end - 12 + ":00pm");
		}
		myAuction = new Auction(myOrganizationName, myDate, myStart, myEnd);
		myEditAuction = true;
		myAddItem = true;
	}
	
	/**
	 * Edits a currently existing auction.
	 */
	@SuppressWarnings("deprecation")
	static
	void editAuction() {
		System.out.println("Please enter the key of what you want to edit "
				+ "(m for month, d for day, y for year, s for start time, n for end time, and e to exit): ");
		Scanner theScn = null;
		String change = theScn.next();
		while(change != "e") {
			if(change == "m") {
				System.out.println("Enter the auction month: ");
				int month = theScn.nextInt();
				while(month < 1 || month > 12) {
					System.out.println("Error. Could not set date. Enter the auction month: ");
					month = theScn.nextInt();
				}
				if(month == 1) {
					myMonth = "January";
				} else if(month == 2) {
					myMonth = "February";
				} else if(month == 3) {
					myMonth = "March";
				} else if(month == 4) {
					myMonth = "April";
				} else if(month == 5) {
					myMonth = "May";
				} else if(month == 6) {
					myMonth = "June";
				} else if(month == 7) {
					myMonth = "July";
				} else if(month == 8) {
					myMonth = "August";
				} else if(month == 9) {
					myMonth = "September";
				} else if(month == 10) {
					myMonth = "October";
				} else if(month == 11) {
					myMonth = "November";
				} else {
					myMonth = "December";
				}
				myDate.setMonth(month);
				myAuction.setMyDate(myDate);
			} else if(change == "d") {
				System.out.println("Enter the auction day: ");
				int day = theScn.nextInt();
				while(day < 1 || day > 30) {
					System.out.println("Error. Could not set date. Enter the auction day: ");
					day = theScn.nextInt();
				}
				myDay = day;
				myDate.setDate(day);
				myAuction.setMyDate(myDate);
			} else if(change == "y") {
				System.out.println("Enter the auction year: ");
				int year = theScn.nextInt();
				while(year < Calendar.YEAR) {
					System.out.println("Error. Could not set date. Enter the auction year: ");
					year = theScn.nextInt();
				}
				myYear = year;
				myDate.setYear(year);
				myAuction.setMyDate(myDate);
			} else if(change == "s") {
				System.out.println("Enter the auction start hour: ");
				int start = myIn.nextInt();
				while(start < 0 || start > 24) {
					System.out.println("Error. Could not set date. Enter the auction hour: ");
					start = myIn.nextInt();
				}
				if(start < 12) {
					myStart = (start + ":00am");
				} else {
					myStart = (start - 12 + ":00pm");
				}
			} else if(change == "n") {
				System.out.println("Enter the auction end hour(0 hour is 12am): ");
				int end = myIn.nextInt();
				while(end < 0 || end > 23) {
					System.out.println("Error. Could not set date. Enter the auction hour: ");
					end = myIn.nextInt();
				}
				if(end < 12) {
					myEnd = (end + ":00am");
				} else {
					myEnd = (end - 12 + ":00pm");
				}
			} else {
				System.out.println("Please enter the key of what you want to edit "
						+ "(m for month, d for day, y for year, s for start time, n for end time, and e to exit): ");
				change = theScn.next();
			}
		}
	}
	
	/**
	 * Adds an item to the current available auction for this non profit organization.
	 */
	static void addNewItem() {
		myCounter++;
		System.out.println("Please enter the item name: ");
		String name = myIn.nextLine();
		System.out.println("Please enter the item description: ");
		String description = myIn.nextLine();
		System.out.print("Please enter the minimum bid for this item: ");
		int minimumBid = myIn.nextInt();
		myAuction.addItem(name, description, minimumBid);
		myEditItem = true;
	}
	
	/**
	 * Edits a currently existing item.
	 */
	static void editItem() {
		System.out.println("Please enter the id of the item you wish to edit: ");
		int id = myIn.nextInt();
		myItem = myAuction.getItem(id);
		System.out.println("Please enter the key of what you want to edit "
				+ "(n for name, d for description, b for minimum bid, and e to exit): ");
		String change = myIn.next();
		while(change != "e") {
			if(change == "n"){
				System.out.println("Please enter the item name: ");
				myAuction.editItemName(id, myIn.nextLine());
			} else if(change == "d") {
				System.out.println("Please enter the item description: ");
				myAuction.editItemDes(id, myIn.nextLine());
			} else if(change == "b") {
				System.out.print("Please enter the minimum bid for this item: ");
				myAuction.editItemMinBid(id, myIn.nextInt());
			} else {
				System.out.println("Please enter the id of the item you wish to edit: ");
				id = myIn.nextInt();
				myItem = myAuction.getItem(id);
				System.out.println("Please enter the key of what you want to edit "
						+ "(i for id, n for name, d for description, b for minimum bid, and e to exit): ");
				change = myIn.next();
			}
		}
	}
}