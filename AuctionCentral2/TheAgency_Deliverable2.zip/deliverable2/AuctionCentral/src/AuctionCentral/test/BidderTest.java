package AuctionCentral;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class BidderTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testBidder() {
		fail("Not yet implemented");
	}

	@Test
	public void testChangeBid() {
		fail("Not yet implemented");
	}

	@Test
	public void testCancelBid() {
		fail("Not yet implemented");
	}

	@Test
	public void testEnterBid() {
		fail("Not yet implemented");
	}

}
